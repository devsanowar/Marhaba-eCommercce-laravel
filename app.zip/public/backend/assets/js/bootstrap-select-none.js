document.querySelectorAll('select').forEach(select => {
    select.classList.remove('bootstrap-select', 'form-select', 'btn-group', 'form-control', 'dropup', ); // Remove unwanted classes
});